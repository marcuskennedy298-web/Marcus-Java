public class Loan
{
    // Fields
    private String name;
    private double loanAmt;
    private double pymtAmt;
    private double intRate;
    private int numPymts;


    // No-args constructor
    public Loan()
    {
        name = "";
        loanAmt = 0.0;
        pymtAmt = 0.0;
        intRate = 0.0;
        numPymts = 0;
    }


    // Full constructor
    public Loan(String n, double lnAmt, double pAmt,
                double iRate, int pymts)
    {
        name = n;
        loanAmt = lnAmt;
        pymtAmt = pAmt;
        intRate = iRate;
        numPymts = pymts;
    }


    // Setters

    public void setName(String n)
    {
        name = n;
    }


    public void setLoanAmt(double lAmt)
    {
        loanAmt = lAmt;
    }


    public void setPymtAmt(double pAmt)
    {
        pymtAmt = pAmt;
    }


    public void setIntRate(double iRate)
    {
        intRate = iRate;
    }


    public void setNumPymts(int pymts)
    {
        numPymts = pymts;
    }


    // Getters

    public String getName()
    {
        return name;
    }


    public double getLoanAmt()
    {
        return loanAmt;
    }


    public double getPymtAmt()
    {
        return pymtAmt;
    }


    public double getIntRate()
    {
        return intRate;
    }


    public int getNumPymts()
    {
        return numPymts;
    }


    // Prints amortization schedule
    public void printAmortSched()
    {
        double balance = loanAmt;
        double interest;
        double principle;
        double newBalance;


        System.out.println();

        System.out.printf("%6s%12s%12s%12s%12s%12s%n",
                "Year",
                "Balance",
                "Payment",
                "Interest",
                "Principle",
                "New Balance");


        for (int year = 1; year <= numPymts; year++)
        {
            interest = balance * intRate;
            principle = pymtAmt - interest;
            newBalance = balance - principle;


            // Prevent negative balance on final payment
            if (year == numPymts)
            {
                principle = balance;
                pymtAmt = principle + interest;
                newBalance = 0;
            }


            System.out.printf("%6d%12.2f%12.2f%12.2f%12.2f%12.2f%n",
                    year,
                    balance,
                    pymtAmt,
                    interest,
                    principle,
                    newBalance);


            balance = newBalance;
        }
    }
}